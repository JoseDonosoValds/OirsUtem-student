package cl.utem.appmovil.appcm202402

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
