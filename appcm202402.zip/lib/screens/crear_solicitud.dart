import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:file_picker/file_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import '../services/api_services.dart'; // Importar el ApiService
import '../utils/user_data.dart'; // Importar el UserModel
import '../utils/navbar.dart'; // Importar el Navbar
import '../utils/classes/get/info_categories.dart'; // Importar la clase para manejar las categorías
import '../utils/appbar.dart'; // Importar el AppBar personalizado

class CrearSolicitudScreen extends StatefulWidget {
  const CrearSolicitudScreen({super.key});

  @override
  _CrearSolicitudScreenState createState() => _CrearSolicitudScreenState();
}

class _CrearSolicitudScreenState extends State<CrearSolicitudScreen> {
  List<CategoryTicketTypes> categories = [];
  List<String> types = []; // Lista para manejar los tipos de solicitud como cadenas de texto
  CategoryTicketTypes? selectedCategory;
  String? selectedType; // Variable para el tipo de solicitud seleccionado
  bool isLoading = true;
  bool isCategorySelected = false;
  bool isTypeSelected = false; // Nueva bandera para verificar si se seleccionó un tipo
  bool isSubjectEntered = false;
  static const String url = 'https://api.sebastian.cl/oirs-utem'; // URL base de tu API
  PlatformFile? selectedFile;

  final TextEditingController _subjectController = TextEditingController();
  final TextEditingController _bodyController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _checkAndRequestStoragePermission();
    _fetchCategories();
    _fetchTypes(); // Llamada para obtener los tipos de solicitudes
  }

  Future<void> _checkAndRequestStoragePermission() async {
    var status = await Permission.storage.status;

    if (!status.isGranted) {
      // Solicitar permiso si aún no ha sido concedido
      status = await Permission.storage.request();

      if (status.isGranted) {
        print('Permiso de almacenamiento concedido');
      } else {
        print('Permiso de almacenamiento denegado');
      }
    } else {
      print('Permiso de almacenamiento ya concedido');
    }
  }

  Future<void> _fetchCategories() async {
    final userModel = Provider.of<UserModel>(context, listen: false);
    final idToken = userModel.idToken; // Obtiene el idToken desde Provider

    final data = await ApiService.get("$url/v1/info/categories", idToken!); // URL de tu API

    if (data != null) {
      setState(() {
        categories = List<CategoryTicketTypes>.from(
          data.map((item) => CategoryTicketTypes.fromJson(item)),
        );
        isLoading = false;
      });
    } else {
      setState(() {
        isLoading = false;
      });
    }
  }

  Future<void> _fetchTypes() async {
    final userModel = Provider.of<UserModel>(context, listen: false);
    final idToken = userModel.idToken; // Obtiene el idToken desde Provider

    final data = await ApiService.get("$url/v1/info/types", idToken!); // URL de tu API

    if (data != null) {
      setState(() {
        types = List<String>.from(data); // Maneja los tipos de solicitud como una lista de Strings
        isLoading = false;
      });
    } else {
      setState(() {
        isLoading = false;
      });
    }
  }

  // Función para enviar la solicitud (POST)
  Future<void> _sendRequest() async {
    final userModel = Provider.of<UserModel>(context, listen: false);
    final idToken = userModel.idToken; // Obtiene el idToken desde Provider

    if (selectedCategory == null || selectedType == null) {
      _showErrorDialog('Por favor selecciona una categoría y un tipo de solicitud.');
      return;
    }

    // Construir la URL dinámica
    final postUrl = "$url/v1/icso/${selectedCategory!.token}/ticket";

    // Crear el body del POST en formato JSON
    final body = {
      "type": selectedType,
      "subject": _subjectController.text,
      "message": _bodyController.text,
    };

    // Hacer el POST
    final response = await ApiService.post(postUrl, idToken!, body);

    if (response != null) {
      _showSuccessDialog('Solicitud enviada exitosamente. :$response');
    } else {
      _showErrorDialog('Error al enviar la solicitud. Por favor, intenta de nuevo.');
    }
  }

  Future<void> _pickFile() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf'],
    );

    if (result != null) {
      setState(() {
        selectedFile = result.files.first;
      });
    }
  }

  void _showSuccessDialog(String message) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Éxito'),
          content: Text(message),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Cerrar el diálogo
              },
              child: const Text('OK'),
            ),
          ],
        );
      },
    );
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Error'),
          content: Text(message),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Cerrar el diálogo
              },
              child: const Text('OK'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(title: 'Crear Solicitud'),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: isLoading
            ? const Center(child: CircularProgressIndicator())
            : Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Categoría:',
                    style: TextStyle(fontSize: 18),
                  ),
                  _buildDropdown<CategoryTicketTypes>(
                    hint: 'Selecciona una categoría',
                    value: selectedCategory,
                    items: categories,
                    onChanged: (value) {
                      setState(() {
                        selectedCategory = value;
                        isCategorySelected = true;
                      });
                    },
                  ),
                  const SizedBox(height: 20),

                  const Text(
                    'Tipo de Solicitud:',
                    style: TextStyle(fontSize: 18),
                  ),
                  _buildDropdown<String>(
                    hint: 'Selecciona el tipo de solicitud',
                    value: selectedType,
                    items: types,
                    onChanged: (value) {
                      setState(() {
                        selectedType = value;
                        isTypeSelected = true;
                      });
                    },
                  ),
                  const SizedBox(height: 20),

                  const Text(
                    'Asunto:',
                    style: TextStyle(fontSize: 18),
                  ),
                  _buildTextField(
                    controller: _subjectController,
                    hintText: 'Ingresa el asunto',
                    enabled: isCategorySelected && isTypeSelected,
                    onChanged: (value) {
                      setState(() {
                        isSubjectEntered = value.isNotEmpty;
                      });
                    },
                  ),
                  const SizedBox(height: 20),

                  const Text(
                    'Cuerpo:',
                    style: TextStyle(fontSize: 18),
                  ),
                  _buildTextField(
                    controller: _bodyController,
                    hintText: 'Escribe el cuerpo de la solicitud',
                    enabled: isCategorySelected &&
                        isTypeSelected &&
                        isSubjectEntered,
                    maxLines: 5,
                  ),
                  const SizedBox(height: 20),
                  
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton.icon(
                      onPressed: _pickFile,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.blueAccent,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15),
                        ),
                      ),
                      icon: const Icon(Icons.attach_file),
                      label: const Text(
                        'Adjuntar Archivo PDF',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),

                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      onPressed: _sendRequest, // Enviar la solicitud
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.orange.shade300,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15),
                        ),
                      ),
                      child: const Text(
                        'Enviar Solicitud',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.black87,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
      ),
      bottomNavigationBar: const Navbar(currentIndex: 0),
    );
  }

  Widget _buildDropdown<T>({
    required String hint,
    required T? value,
    required List<T> items,
    required ValueChanged<T?> onChanged,
  }) {
    return DropdownButton<T>(
      hint: Text(hint),
      isExpanded: true,
      value: value,
      items: items.map((item) {
        return DropdownMenuItem<T>(
          value: item,
          child: Text(item.toString()),
        );
      }).toList(),
      onChanged: onChanged,
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String hintText,
    required bool enabled,
    int maxLines = 1,
    ValueChanged<String>? onChanged,
  }) {
    return TextField(
      controller: controller,
      enabled: enabled,
      decoration: InputDecoration(
        hintText: hintText,
        border: OutlineInputBorder(),
      ),
      maxLines: maxLines,
      onChanged: onChanged,
    );
  }
}
