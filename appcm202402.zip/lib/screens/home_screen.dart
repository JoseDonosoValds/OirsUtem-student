import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:logger/logger.dart';
import 'package:provider/provider.dart';
import '../utils/user_data.dart';
import '../utils/navbar.dart';
import '../utils/appbar.dart'; // Importar el AppBar personalizado

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  static final Logger _logger = Logger();

  @override
  Widget build(BuildContext context) {
    final userModel = Provider.of<UserModel>(context);

    // Log userModel data
    HomeScreen._logger.i(
        'UserModel: ${userModel.displayName}, ${userModel.email}, ${userModel.idToken}, ${userModel.accessToken}');

    if (userModel.email == null) {
      return const Scaffold(
        body: Center(
          child: Text('No user is currently signed in.'),
        ),
      );
    }

    return Scaffold(
      appBar: const CustomAppBar(title: 'Inicio'),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        child: ListView(
          children: [
            // Saludo personalizado
            Text(
              'Hola! ${userModel.displayName ?? '_NOMBRE'}',
              style: GoogleFonts.poppins(
                fontSize: 26,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 10),

            // Crear Solicitud Section
            Text(
              'Crear Solicitud',
              style: GoogleFonts.poppins(
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 10),

            // Fila de opciones para crear solicitudes (adaptativo)
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Flexible(
                  flex: 1,
                  child: _buildSolicitudOption(
                    context,
                    'Reclamo',
                    Icons.warning_amber_rounded,
                    Colors.orange.shade300,
                  ),
                ),
                const SizedBox(width: 10),
                Flexible(
                  flex: 1,
                  child: _buildSolicitudOption(
                    context,
                    'Sugerencia',
                    Icons.lightbulb,
                    Colors.green.shade300,
                  ),
                ),
                const SizedBox(width: 10),
                Flexible(
                  flex: 1,
                  child: _buildSolicitudOption(
                    context,
                    'Información',
                    Icons.info_outline,
                    Colors.blue.shade300,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
      bottomNavigationBar: const Navbar(currentIndex: 0),
    );
  }

  // Widget para construir la opción de crear solicitud
  Widget _buildSolicitudOption(
      BuildContext context, String title, IconData icon, Color color) {
    return Container(
      width: double
          .infinity, // Hacer que ocupe todo el espacio disponible en el Flexible
      height: 120, // Tamaño consistente para todos los elementos
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(15),
      ),
      child: Padding(
        padding:
            const EdgeInsets.all(10.0), // Espaciado interno para el contenido
        child: Column(
          crossAxisAlignment:
              CrossAxisAlignment.start, // Alinear a la izquierda
          children: [
            // Icono en la esquina superior izquierda
            Icon(icon, size: 40, color: Colors.black.withOpacity(0.6)),
            const Spacer(), // Añadir espacio flexible para empujar el texto hacia la parte inferior
            // Texto centrado horizontalmente
            Center(
              child: Text(
                title,
                textAlign: TextAlign.center,
                style: GoogleFonts.poppins(
                  color: Colors.black.withOpacity(0.6),
                  fontSize: 12, // Reducir el tamaño de fuente un 25%
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
